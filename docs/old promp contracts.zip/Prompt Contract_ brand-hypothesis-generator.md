# Prompt Contract: `brand-hypothesis-generator`

## Purpose

Generate a small number of useful, explicitly provisional hypotheses for Brand Brain fields that are important for content generation but insufficiently supported by available evidence.

The hypothesis generator exists to reduce unnecessary founder questions.

It must help the Social Operator become useful sooner without pretending that uncertain information is known.

---

## Input

The model receives:

- current canonical Brand Brain draft;
- extracted evidence;
- known unresolved fields;
- detected source gaps;
- business category or industry, when known;
- business location or market context, when known;
- existing founder-confirmed values;
- fields that are protected from hypothesis generation;
- optional list of fields considered important for the next content cycle.

---

## Core Responsibility

For selected missing or weakly-supported Brand Brain fields:

1. determine whether a useful provisional hypothesis can reasonably be formed;
2. produce the smallest practical hypothesis;
3. explain what evidence or contextual reasoning supports it;
4. identify the risk of using the hypothesis;
5. determine whether founder confirmation is required before operational use.

The model must not attempt to complete the entire Brand Brain.

---

## Key Principle

A hypothesis is a temporary operating assumption.

It is not:

- a fact;
- an observation;
- a founder decision;
- a verified audience profile;
- a final brand strategy.

The system should prefer a transparent hypothesis over an unnecessary questionnaire, but prefer `unknown` over a misleading hypothesis.

---

# 1. Eligible Hypothesis Areas

Hypotheses may be generated for fields such as:

- `audience.primary_segments`
- `audience.needs`
- `audience.objections`
- `audience.decision_drivers`
- `positioning.core_position`
- `positioning.brand_attributes`
- `voice.primary_tone`
- `voice.formality`
- `voice.energy`
- `content.pillars`
- `content.recurring_topics`
- `content.cta_preferences`

These are fields where a provisional assumption may sometimes enable useful content generation.

---

# 2. Restricted Areas

Do not generate hypotheses for information that should normally be factual or explicitly authorized.

Examples:

- business name;
- address;
- pricing;
- credentials;
- certifications;
- years of experience;
- awards;
- statistics;
- equipment;
- medical outcomes;
- guarantees;
- legal claims;
- regulatory status;
- opening hours;
- founder-confirmed priorities;
- founder-confirmed prohibitions.

If these are unknown, leave them unknown.

---

# 3. Hypothesis Sources

A hypothesis may be based on:

### Direct source signals

Example:

The website repeatedly emphasizes family dentistry and pediatric services.

Possible hypothesis:

> Families with children are likely to be an important audience segment.

---

### Repeated communication patterns

Example:

Most recent posts explain procedures in simple language and reassure anxious patients.

Possible hypothesis:

> Reassurance and education may be important communication functions.

---

### Business context

Industry and market context may be used only as weak supporting context.

Example:

A restaurant has no stated CTA preference.

A hypothesis such as:

> Reservation-oriented CTAs may be useful.

may be reasonable.

But business category alone must not produce detailed strategic assumptions.

---

### Combination of weak signals

Several weak but consistent signals may justify one cautious hypothesis.

---

# 4. Forbidden Reasoning

Do not produce hypotheses solely from stereotypes.

Examples of prohibited reasoning:

- luxury service → wealthy women;
- dental clinic → women aged 25–45;
- startup → young urban professionals;
- Georgian business → conservative tone;
- premium website → high-income audience;
- English-language content → international customers.

These may occasionally be true, but they require supporting evidence.

---

# 5. Hypothesis Granularity

Generate the smallest useful assumption.

Prefer:

> Price sensitivity may be a meaningful objection.

Over:

> The primary audience is middle-income families aged 30–45 who compare several providers before purchasing.

Prefer:

> A calm, expert tone is likely to fit existing communication.

Over:

> The brand personality is a sophisticated caregiver archetype combining authority, warmth and restrained optimism.

Avoid unnecessary strategic fiction.

---

# 6. Operational Safety

Each hypothesis must be classified by operational risk.

Use:

- `safe_to_use`
- `use_cautiously`
- `confirmation_required`

---

## `safe_to_use`

The hypothesis is low-risk and can guide ordinary content without creating material factual or strategic risk.

Examples:

- favor educational content;
- use a restrained tone;
- avoid overly aggressive sales language.

---

## `use_cautiously`

The hypothesis can influence planning, but should not be stated publicly as if confirmed.

Examples:

- likely audience need;
- likely objection;
- likely positioning direction.

---

## `confirmation_required`

The assumption materially affects business strategy, public claims, targeting or messaging and should not be operationalized without founder confirmation.

Examples:

- primary target segment;
- premium vs budget positioning;
- major business priority;
- sensitive audience assumption.

---

# 7. Founder Question Avoidance

A hypothesis should be generated when all of the following are true:

1. the missing information would improve content generation;
2. the information is not available from existing sources;
3. a provisional assumption is reasonably defensible;
4. using the assumption does not create significant risk.

Do not generate a founder question merely because a schema field is empty.

---

# 8. When to Prefer `unknown`

Return no hypothesis when:

- evidence is contradictory;
- available signals are too weak;
- the assumption would materially affect public claims;
- the assumption could create reputational or legal risk;
- founder intent is essential;
- several equally plausible interpretations exist;
- the field is factual rather than interpretive.

---

# 9. Output Structure

Return structured JSON only.

Each proposed hypothesis should conceptually follow:

```json
{
  "field": "voice.primary_tone",
  "value": ["calm", "professional"],
  "status": "hypothesis",
  "operational_risk": "safe_to_use",
  "reasoning_summary": "Recent website and social content consistently use restrained, explanatory language with limited promotional urgency.",
  "supporting_evidence_ids": [
    "ev_014",
    "ev_027",
    "ev_041"
  ],
  "evidence_strength": "medium",
  "founder_confirmation": {
    "required": false,
    "priority": null
  }
}
```

---

# 10. Reasoning Summary

The output may include a concise explanation of why the hypothesis was proposed.

The explanation must:

- reference available evidence;
- distinguish evidence from interpretation;
- avoid unsupported certainty;
- remain short enough for inspection and debugging.

Do not output hidden chain-of-thought or long internal reasoning.

---

# 11. Evidence Strength

Use:

- `strong`
- `medium`
- `weak`

This represents how well the available evidence supports forming the hypothesis.

It is not numeric confidence.

Numeric confidence remains application-generated.

---

# 12. Hypothesis Count

Generate only hypotheses that materially improve the Brand Brain.

Do not attempt to populate every empty eligible field.

Application logic should normally cap hypotheses per pass.

Recommended default:

- maximum 5 high-value hypotheses per generation pass.

The exact enforcement belongs to application logic.

---

# 13. Founder Confirmation Priority

When confirmation is needed, assign:

- `high`
- `medium`
- `low`

### `high`

The answer materially changes what content the Operator creates.

### `medium`

The answer improves quality but reasonable work can continue without it.

### `low`

Useful refinement, but not onboarding-critical.

Only high-priority unresolved assumptions should normally compete for the limited founder-question budget.

---

# 14. Interaction with Confirmed Fields

Never generate a competing hypothesis against a founder-confirmed field unless the system explicitly asks for conflict analysis.

If new evidence appears inconsistent with a confirmed field, pass the issue to the conflict detection layer.

Do not silently reinterpret the founder's decision.

---

# 15. Interaction with MVB

Hypotheses may help satisfy operational readiness for:

- tone;
- basic content direction.

However:

- at least one real service/product must still be known;
- at least one content language must still be known.

Do not fabricate factual MVB components.

---

# 16. Examples

## Example A — Good hypothesis

Evidence:

- website explanations are detailed;
- recent posts answer common patient questions;
- promotional content is limited.

Output:

> `content.pillars = ["education"]`

Status:

> `hypothesis`

Operational risk:

> `safe_to_use`

Reason:

> Educational communication is repeatedly observable across existing sources.

---

## Example B — Good cautious hypothesis

Evidence:

- several posts discuss treatment anxiety;
- clinic repeatedly emphasizes painless or comfortable experience.

Output:

> `audience.objections = ["fear or anxiety around treatment"]`

Operational risk:

> `use_cautiously`

The Operator may create reassuring educational content but should not describe this as a verified primary customer objection.

---

## Example C — Bad hypothesis

Input:

> Business type: dental clinic in Tbilisi.

Bad output:

> Primary audience: women aged 30–50 with above-average income.

Reason:

No source evidence supports demographic, gender or income assumptions.

Return no hypothesis.

---

## Example D — Founder confirmation required

Evidence:

- premium visual identity;
- high-end equipment;
- polished website;
- no explicit pricing or founder positioning statement.

Possible hypothesis:

> The brand may intend a premium positioning.

Operational risk:

> `confirmation_required`

This should not become canonical positioning merely from visual signals.

---

# 17. Failure Behavior

If no useful hypotheses can be generated, return an empty hypothesis array.

This is a valid result.

Never reduce quality thresholds merely to produce output.

The system should remain partially unknown rather than confidently wrong.