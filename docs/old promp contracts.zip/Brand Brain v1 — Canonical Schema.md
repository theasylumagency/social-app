# Brand Brain v1 — Canonical Schema

## Purpose

The Brand Brain is the canonical structured representation of what the Social Operator currently knows about a brand.

It is used to:

- plan content;
- generate posts;
- choose tone and messaging;
- avoid unsupported claims;
- preserve founder-confirmed decisions;
- explain why the Operator made a content decision;
- improve over time as new evidence and feedback become available.

The Brand Brain is **not** a general company database, CRM, website mirror, or exhaustive brand strategy document.

Only information that materially helps the Social Operator create better content belongs here.

---

# 1. Core Structure

```json
{
  "identity": {},
  "offer": {},
  "audience": {},
  "positioning": {},
  "voice": {},
  "content": {},
  "proof": {},
  "constraints": {},
  "metadata": {}
}
```

---

# 2. `identity`

Basic information required to understand who the brand is.

```json
{
  "identity": {
    "name": null,
    "short_description": null,
    "industry": null,
    "locations": [],
    "languages": [],
    "website": null,
    "social_accounts": []
  }
}
```

### `name`

Canonical public-facing brand name.

### `short_description`

One concise description of what the business is.

Example:

> Dental clinic providing general, aesthetic, orthodontic and implant dentistry in Tbilisi.

This should describe the business rather than market it.

### `industry`

Normalized business category.

Examples:

- dental_clinic
- restaurant
- beauty_salon
- ecommerce
- real_estate
- professional_services

The normalized value is primarily system metadata.

### `locations`

Relevant operating locations.

Do not attempt to reproduce a complete corporate address database unless location materially affects content.

### `languages`

Languages the brand communicates in or intends the Operator to use.

At least one content language is required for a viable Brand Brain.

### `website`

Canonical website when available.

### `social_accounts`

Connected or analyzed social accounts.

This is source context, not authentication data.

---

# 3. `offer`

What the brand actually sells or provides.

```json
{
  "offer": {
    "primary_services": [],
    "secondary_services": [],
    "products": [],
    "priority_offers": [],
    "pricing_context": null
  }
}
```

### `primary_services`

Core services that materially represent the business.

At least one service or product must exist for the Brand Brain to become viable.

### `secondary_services`

Relevant but non-core services.

### `products`

Use when the business primarily or materially sells products.

### `priority_offers`

Services, products, packages or categories the business currently wants to emphasize.

This is distinct from the complete service catalog.

Example:

The clinic may provide 14 services but currently want the Operator to emphasize:

- hygiene;
- aligners;
- implants.

### `pricing_context`

Only high-level pricing information useful for communication.

Examples:

- premium;
- mid-market;
- budget-conscious;
- prices publicly displayed;
- consultation required before quote.

Do not infer affordability or customer income merely from listed prices.

---

# 4. `audience`

Who the communication is intended for.

```json
{
  "audience": {
    "primary_segments": [],
    "secondary_segments": [],
    "needs": [],
    "objections": [],
    "decision_drivers": []
  }
}
```

### `primary_segments`

The most relevant customer groups.

Segments should normally be behavioral or need-based rather than invented demographic personas.

Prefer:

> Parents seeking pediatric dental care.

Over:

> Women aged 28–42, middle income.

unless the demographic information is actually supported.

### `secondary_segments`

Meaningful but lower-priority audiences.

### `needs`

Problems, jobs-to-be-done or desired outcomes.

### `objections`

Known concerns that commonly block conversion.

Examples:

- price uncertainty;
- fear of treatment;
- lack of trust;
- uncertainty about results;
- time commitment.

Do not invent objections solely because they are common in an industry.

### `decision_drivers`

Known factors that influence customer choice.

Examples:

- physician expertise;
- location;
- speed;
- warranty;
- design;
- price;
- technology;
- personal service.

---

# 5. `positioning`

How the brand should be understood relative to alternatives.

```json
{
  "positioning": {
    "core_position": null,
    "value_propositions": [],
    "differentiators": [],
    "brand_attributes": [],
    "avoid_positioning": []
  }
}
```

### `core_position`

One concise strategic sentence.

Example:

> A modern dental clinic combining specialist care with a calm, high-trust patient experience.

This should only become strong canonical positioning when evidence or founder confirmation supports it.

### `value_propositions`

Reasons a customer may choose the brand.

### `differentiators`

Specific characteristics that distinguish the business from alternatives.

Avoid generic pseudo-differentiators such as:

- quality;
- professionalism;
- individual approach;

unless they are expressed in a more concrete and defensible way.

### `brand_attributes`

A small set of descriptors useful for communication.

Examples:

- calm;
- expert;
- modern;
- approachable;
- understated;
- energetic.

Prefer approximately 3–5 useful attributes rather than a long adjective list.

### `avoid_positioning`

How the brand explicitly does **not** want to present itself.

Examples:

- cheap;
- aggressive;
- luxury;
- playful;
- corporate.

This becomes particularly valuable after founder feedback.

---

# 6. `voice`

How the brand communicates.

```json
{
  "voice": {
    "primary_tone": [],
    "formality": null,
    "energy": null,
    "emotional_style": null,
    "language_rules": [],
    "preferred_patterns": [],
    "avoid_patterns": [],
    "examples": []
  }
}
```

### `primary_tone`

Approximately 2–4 dominant tone attributes.

Examples:

- professional;
- calm;
- warm;
- concise.

At least one usable tone definition is required for a viable Brand Brain.

### `formality`

Suggested normalized values:

- formal
- balanced
- conversational

### `energy`

Suggested normalized values:

- restrained
- moderate
- energetic

### `emotional_style`

Examples:

- reassuring;
- optimistic;
- authoritative;
- playful;
- aspirational.

### `language_rules`

Brand-specific linguistic rules.

Examples:

- use Georgian terminology rather than untranslated English;
- address the audience formally;
- avoid excessive emojis;
- use short paragraphs.

### `preferred_patterns`

Known successful or desired communication patterns.

### `avoid_patterns`

Patterns the Operator should avoid.

Examples:

- exaggerated urgency;
- clickbait;
- excessive exclamation marks;
- generic inspirational quotes.

### `examples`

Founder-approved or source-supported examples that strongly demonstrate the desired voice.

These are reference examples, not templates to reproduce verbatim.

---

# 7. `content`

What the Operator should talk about and why.

```json
{
  "content": {
    "goals": [],
    "pillars": [],
    "priority_topics": [],
    "recurring_topics": [],
    "content_mix_preferences": [],
    "cta_preferences": [],
    "seasonal_context": []
  }
}
```

### `goals`

Business-relevant communication goals.

Examples:

- generate consultations;
- increase awareness;
- educate patients;
- reactivate existing customers;
- support product launches;
- build trust.

Do not infer goals solely from industry.

### `pillars`

Stable high-level content territories.

Example for a clinic:

- expertise;
- patient education;
- treatments;
- technology;
- trust.

Pillars should not be generated merely to fill a quota.

### `priority_topics`

Topics currently deserving increased attention.

### `recurring_topics`

Topics useful over a long period.

### `content_mix_preferences`

Optional founder-confirmed or learned preferences.

Examples:

- more educational than promotional;
- approximately one direct offer per week;
- prioritize real team content.

This field should guide planning, not act as a rigid publishing formula.

### `cta_preferences`

Preferred calls to action.

Examples:

- book a consultation;
- message us;
- visit the website;
- call the clinic;
- save the post.

### `seasonal_context`

Recurring seasonal or calendar-related context relevant to the business.

---

# 8. `proof`

What the Operator may use to support claims.

```json
{
  "proof": {
    "credentials": [],
    "experience": [],
    "numbers": [],
    "technology": [],
    "awards": [],
    "testimonials": [],
    "case_evidence": []
  }
}
```

This section is deliberately separate from positioning.

It answers:

> What evidence do we actually have?

### `credentials`

Licenses, qualifications, certifications, partnerships and similar facts.

### `experience`

Supported experience claims.

### `numbers`

Verified or brand-supplied quantitative evidence.

Examples:

- years in business;
- patients served;
- locations;
- completed projects.

A number must retain provenance and freshness metadata.

### `technology`

Specific equipment, platforms or technical capabilities that may legitimately be referenced.

### `awards`

Actual awards or recognitions.

### `testimonials`

Approved customer evidence where available.

### `case_evidence`

Cases, before/after material, outcomes or examples that can safely support content.

---

# 9. `constraints`

Information that prevents the Operator from producing harmful, inaccurate or off-brand content.

```json
{
  "constraints": {
    "prohibited_claims": [],
    "sensitive_topics": [],
    "legal_or_regulatory": [],
    "brand_rules": [],
    "approval_required": []
  }
}
```

### `prohibited_claims`

Claims the system must not make.

Examples:

- “best in Georgia”;
- guaranteed results;
- unsupported medical outcomes.

### `sensitive_topics`

Subjects requiring special caution or avoidance.

### `legal_or_regulatory`

Known content constraints applicable to the business.

These should not be invented by the Brand Brain model from general legal knowledge unless a dedicated compliance system supplies them.

### `brand_rules`

Explicit operational restrictions.

Examples:

- never mention a former parent brand;
- do not publish prices;
- never use competitor names.

### `approval_required`

Categories that should require human approval before publishing.

This can later interact with Operator Mode / Review Mode.

---

# 10. Field-Level Knowledge Metadata

Canonical values must not exist without knowledge-state metadata.

Every meaningful Brand Brain field or item should be capable of carrying:

```json
{
  "value": "...",
  "status": "confirmed | observed | inferred | hypothesis",
  "confidence": 0.0,
  "sources": [],
  "updated_at": "...",
  "confirmed_by": null
}
```

The exact persistence model may differ in implementation, but these concepts must survive.

---

## `status`

### `confirmed`

Explicitly confirmed by the founder or authorized user.

This has the highest authority.

A model must never silently overwrite a founder-confirmed value.

### `observed`

Supported directly by reliable source evidence.

### `inferred`

Derived from evidence but not explicitly stated.

### `hypothesis`

A provisional assumption created because useful information is missing.

Hypotheses must remain visibly distinguishable from known information.

---

# 11. Source Provenance

Every non-trivial value should be traceable to one or more evidence items.

Conceptually:

```json
{
  "sources": [
    {
      "evidence_id": "ev_042",
      "source_id": "src_website_home"
    }
  ]
}
```

The Brand Brain should not duplicate full source content.

It references evidence retained in the evidence layer.

---

# 12. Confidence

Numeric confidence is application-generated.

The LLM may provide semantic evidence assessments, but it does not decide the canonical numeric confidence score.

Confidence can incorporate:

- evidence type;
- evidence strength;
- number of supporting sources;
- source reliability;
- source freshness;
- conflicts;
- founder confirmation.

Founder confirmation should normally supersede source-based uncertainty unless contradictory founder-confirmed information exists.

---

# 13. Conflict State

A field may contain unresolved competing candidates.

Conceptually:

```json
{
  "status": "conflicted",
  "candidates": [],
  "resolution_required": true
}
```

The synthesizer must not silently choose between materially conflicting values when the evidence is insufficient.

Only conflicts that materially affect content generation should normally be surfaced to the founder.

---

# 14. Minimum Viable Brand Brain

The Social Operator may begin useful work when the Brand Brain contains at minimum:

1. at least one usable service or product;
2. at least one usable content language;
3. a usable tone definition.

This is the **Minimum Viable Brand Brain (MVB)**.

MVB does not mean onboarding is fully complete.

Missing fields can continue to improve through:

- source ingestion;
- founder answers;
- content feedback;
- publishing history;
- future Brand Brain refreshes.

The system should prefer operating with a transparent partial Brand Brain over forcing the founder through a long questionnaire.

---

# 15. Founder Question Budget

The Brand Brain onboarding flow may surface:

- maximum **5–7 founder-only questions**;
- maximum **3–5 material conflicts**.

Questions should only be asked when:

1. the answer materially affects content generation;
2. the answer cannot reasonably be obtained from available sources;
3. a useful hypothesis would be too risky or misleading.

The Brand Brain should not attempt to complete every schema field during onboarding.

---

# 16. Canonical Authority Order

When determining canonical Brand Brain values, use approximately the following authority hierarchy:

1. current founder-confirmed value;
2. explicit current business source;
3. multiple consistent observations;
4. model inference;
5. generated hypothesis.

However, authority alone does not automatically resolve every conflict.

Freshness and context must also be considered.

---

# 17. Update Protection

Founder-confirmed fields are protected.

New source evidence may:

- support them;
- reduce confidence in source consistency;
- create a conflict;
- prompt a future confirmation request.

It must **not** silently replace them.

Only:

- explicit founder action;
- authorized user action;
- or an explicitly defined reconciliation workflow

may replace a founder-confirmed canonical value.

---

# 18. Schema Philosophy

The Brand Brain should obey five principles:

### Content relevance

Store information because it improves Social Operator decisions, not merely because it exists.

### Evidence before invention

Prefer incomplete knowledge to fabricated completeness.

### Explicit uncertainty

Observed information, inference and hypothesis must remain distinguishable.

### Founder authority

Founder-confirmed strategic decisions outrank model interpretation.

### Progressive refinement

The first Brand Brain is a usable beginning, not a final questionnaire-derived document.