# Prompt Contract: `brand-brain-summary`

## Purpose

Transform the canonical Brand Brain into a concise founder-facing review summary.

The summary exists to help the user quickly understand:

- what the Operator learned;
- what it currently believes about the brand;
- what was explicitly confirmed;
- what remains uncertain;
- whether the Brand Brain is ready to use.

The summary must not modify the Brand Brain.

---

# 1. Input

The model receives:

- canonical Brand Brain;
- operational readiness status;
- MVB status;
- remaining material uncertainties;
- unresolved but non-blocking conflicts;
- active hypotheses;
- founder-confirmed values;
- optional safe operating envelope.

---

# 2. Core Responsibility

The summary generator must:

1. translate structured Brand Brain data into plain language;
2. prioritize information that materially affects future content;
3. clearly distinguish confirmed knowledge from provisional assumptions when relevant;
4. omit technical metadata;
5. avoid overwhelming the founder with details;
6. make review fast enough to scan in under a minute.

The summary is a presentation layer, not a reasoning layer.

---

# 3. Summary Philosophy

The user should feel:

> The system already understands a lot, and I only need to correct something if it looks wrong.

The user should not feel:

> I have been handed another brand strategy document to review.

The summary should therefore be selective.

---

# 4. Recommended Review Structure

The default review should contain approximately:

1. **What you do**
2. **Who you speak to**
3. **How the brand should sound**
4. **What content should focus on**
5. **Important rules**
6. **What we're still assuming**, only when material

Not every section must appear.

Empty or low-value sections should be omitted.

---

# 5. `What you do`

Summarize:

- primary service/product categories;
- meaningful current priorities;
- relevant location or market context only when useful.

Example:

> You are a dental clinic in Tbilisi focused on implantology, orthodontics, aesthetic dentistry and general dental care. For the current content cycle, implants are the highest-priority service.

Do not reproduce the entire service catalog.

---

# 6. `Who you speak to`

Summarize only audience information that is sufficiently useful.

Example:

> Your main audiences are adults considering restorative or aesthetic treatment and families looking for ongoing dental care.

Avoid artificial persona language.

Do not surface unsupported demographic assumptions.

---

# 7. `How the brand should sound`

Summarize:

- dominant tone;
- formality;
- energy;
- important language rules.

Example:

> The default voice should be calm, professional and reassuring — informative rather than sales-heavy, with limited use of emojis and urgency.

This section is particularly important because founders can usually recognize incorrect tone quickly.

---

# 8. `What content should focus on`

Summarize:

- current communication goals;
- content pillars;
- priority topics;
- important CTA direction.

Example:

> Content should mainly build trust and educate patients, while regularly supporting priority services and encouraging consultation bookings.

Do not display internal taxonomy such as `content.pillars`.

---

# 9. `Important rules`

Include only constraints that materially affect generation.

Examples:

- never publish prices;
- do not make guaranteed outcome claims;
- avoid aggressive promotional language;
- do not mention a former brand;
- some content requires approval.

Explicit negative rules should be highly visible.

---

# 10. Provisional Knowledge

When an important value is not founder-confirmed, the summary may surface it as an assumption.

Prefer natural language such as:

> We're currently assuming that...

or:

> Based on your existing content, we're treating...

Do not expose internal terms like:

- `hypothesis`;
- `confidence = 0.62`;
- `inferred candidate`.

---

# 11. When to Surface an Assumption

Surface uncertainty only when:

1. it materially affects generated content;
2. founder awareness would be useful;
3. the issue was not already resolved in onboarding.

Do not clutter the review with every inferred field.

Example worth surfacing:

> Based on your current content, we're treating the brand as more premium than price-led.

Example not worth surfacing:

> We inferred that educational content may be useful.

---

# 12. Confirmed vs Inferred Presentation

Do not label every field with status badges in prose.

Use status cues selectively.

Possible UI-friendly concepts:

- `Confirmed`
- `Based on your current content`
- `We'll use this for now`

The prompt may return metadata to support such UI treatment, but visible prose should remain natural.

---

# 13. No New Interpretation

The summary must not create new strategic language that is stronger than the canonical Brand Brain.

If canonical positioning says:

> calm specialist dental clinic

the summary must not upgrade it to:

> Tbilisi's leading premium destination for world-class dentistry.

Summarization must preserve epistemic strength.

---

# 14. No Marketing Copy

This is not public-facing brand copy.

Avoid:

- slogans;
- exaggerated adjectives;
- persuasive language;
- polished mission statements;
- inspirational branding prose.

Prefer clarity over elegance.

---

# 15. Compression

The summary should compress information aggressively.

Recommended default:

- 4–6 sections;
- approximately 1–3 short sentences per section;
- no long lists;
- no full provenance details.

The complete Brand Brain remains available separately.

---

# 16. Review Corrections

Where useful, each section should map back to editable Brand Brain fields.

Conceptually:

```json
{
  "section": "voice",
  "editable_fields": [
    "voice.primary_tone",
    "voice.formality",
    "voice.energy"
  ]
}
```

This enables UI actions such as:

- Edit
- Correct
- Looks right

The summary model itself does not perform the edit.

---

# 17. Readiness Message

The summary should reflect operational readiness.

### `ready`

Use a simple message such as:

> Brand Brain is ready. The Operator has enough context to start planning content.

### `ready_with_uncertainty`

Use:

> Brand Brain is ready to use. A few details can improve over time, but they don't need to block the first content cycle.

### `blocked`

Clearly identify only the missing information that prevents safe operation.

Example:

> We still need to know which language the Operator should publish in before we can start.

Do not describe the whole Brand Brain as incomplete.

---

# 18. MVB Presentation

Do not expose the term `Minimum Viable Brand Brain` unless it is useful internally or the product explicitly chooses to use it.

Founder-facing UX should simply communicate readiness.

Internal output may still include MVB metadata.

---

# 19. Unresolved Conflict Presentation

Only display a conflict when it remains materially relevant.

Example:

> Your website presents the brand as premium, while recent campaigns are strongly price-led. For now, the Operator will avoid making either positioning dominant.

This is better than exposing raw candidate values and conflict IDs.

---

# 20. Safe Operating Envelope

When unresolved issues constrain generation, explain the practical consequence.

Example:

> Pricing information is inconsistent across your sources, so the Operator will avoid publishing specific prices until this is clarified.

This is useful and trust-building.

Do not show technical safety rules that have no visible impact.

---

# 21. Output Structure

Return structured JSON only.

Recommended conceptual format:

```json
{
  "headline": "Here's what the Operator learned about your brand",
  "sections": [
    {
      "id": "offer",
      "title": "What you do",
      "summary": "You are a dental clinic...",
      "editable_fields": [
        "offer.primary_services",
        "offer.priority_offers"
      ],
      "review_priority": "high"
    },
    {
      "id": "voice",
      "title": "How you should sound",
      "summary": "The default voice should be...",
      "editable_fields": [
        "voice.primary_tone",
        "voice.formality"
      ],
      "review_priority": "high"
    }
  ],
  "assumptions": [],
  "operational_status": "ready_with_uncertainty",
  "readiness_message": "Brand Brain is ready to use..."
}
```

---

# 22. `review_priority`

Use:

- `high`
- `medium`
- `low`

High-priority review sections are those where a wrong interpretation would materially affect content.

Typical high-priority areas:

- offer priorities;
- audience;
- tone;
- constraints;
- positioning.

Low-priority sections may be collapsed or hidden by default.

---

# 23. Assumptions Output

When material assumptions exist:

```json
{
  "field": "positioning.core_position",
  "summary": "Based on your current website and social content, we're treating the brand as premium and specialist-led.",
  "impact": "medium",
  "editable_fields": [
    "positioning.core_position"
  ]
}
```

Keep assumptions concise.

---

# 24. Source Awareness

The summary may say:

- “Based on your website...”
- “From your recent social content...”
- “You confirmed that...”

when this materially builds trust.

Do not cite every source.

Do not expose raw URLs unless the UI specifically requests them.

---

# 25. Founder Corrections

The summary should be written so that correction is easy.

Prefer concrete statements:

> The default tone is calm and professional.

Over abstract language:

> Your brand embodies an understated fusion of expertise and warmth.

Concrete statements are easier to approve or reject.

---

# 26. Language

Return founder-facing content in the user's active product language.

Do not automatically use the brand's publishing language for onboarding UI.

Example:

A Georgian founder may operate an English-language brand.

The review UI may still be Georgian while describing English content rules.

---

# 27. Multiple Publishing Languages

If the Brand Brain has multiple publishing languages, summarize only material differences.

Example:

> Content will be created in Georgian and English, using the same core tone in both languages.

If tone or terminology differs by language, surface that distinction.

---

# 28. Avoid False Completeness

Never write:

> We now fully understand your brand.

Prefer:

> We have enough context to start.

The Brand Brain is designed to evolve.

---

# 29. Progressive Refinement Message

When appropriate, the readiness message may reinforce that future feedback improves the system.

Example:

> The Operator can start from this profile and refine it as you review content and add new information.

Keep this secondary.

Do not make onboarding feel unfinished.

---

# 30. Failure Behavior

If the Brand Brain contains very little information:

- summarize only what is defensible;
- do not pad the review with generic statements.

If operational status is blocked:

- clearly state the blocker;
- omit irrelevant sections.

If no material assumptions remain:

- return an empty assumptions array.

If the Brand Brain is unchanged from a previous review:

- produce a semantically stable summary rather than creative variation.

---

# 31. Non-Responsibilities

The Brand Brain summary must not:

- modify canonical data;
- create new hypotheses;
- calculate confidence;
- resolve conflicts;
- generate founder questions;
- generate social posts;
- invent positioning language;
- hide meaningful operational restrictions;
- expose internal chain-of-thought.