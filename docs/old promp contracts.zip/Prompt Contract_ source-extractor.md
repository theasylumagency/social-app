# Prompt Contract: `source-extractor`

## Purpose

Convert a single source into structured evidence that may later be used to construct or update a Brand Brain.

The extractor is an evidence collection component.

It does **not** construct the Brand Brain, resolve conflicts, infer missing business strategy, or fill information gaps using general knowledge.

---

## Input

The model receives:

- source content;
- source type;
- source URL or source identifier where available;
- source publication/update date where available;
- retrieval date;
- source language;
- optional structural context such as page title, section name, post type, or document heading.

---

## Core Responsibility

Extract only information supported by the supplied source.

For every meaningful item, determine:

1. what the source communicates;
2. what kind of evidence it is;
3. which Brand Brain field it may be relevant to;
4. the exact evidence supporting it;
5. whether freshness may be a concern.

Do not determine the final canonical Brand Brain value.

---

## Evidence Types

### `fact`

Information explicitly stated by the source and presented as an objective property of the business.

Examples:

- business name;
- address;
- supported languages;
- listed services;
- published opening hours.

A statement should not be classified as a fact merely because the business presents it confidently.

---

### `claim`

A statement the brand makes about itself that cannot be treated as independently established fact.

Examples:

- “the best clinic in Tbilisi”;
- “industry-leading quality”;
- “the most trusted provider”;
- “premium service”.

Preserve the claim. Do not convert it into a fact.

---

### `observation`

A directly observable characteristic or pattern of the supplied source.

Examples:

- most recent posts are promotional;
- captions consistently use formal Georgian;
- the page repeatedly uses price-led calls to action;
- physician portraits dominate the visual content.

Observations must describe what is visible in the supplied source, not why the business behaves that way.

---

### `inference`

A plausible interpretation supported by source evidence but not stated directly.

Examples:

- the brand appears to prioritize price-based conversion;
- communication appears directed primarily toward existing patients;
- the brand may be attempting to position itself as premium.

Inference must never be expressed as established fact.

Use inference sparingly.

---

### `outdated_candidate`

Information that may once have been valid but whose current validity is uncertain because of source age, explicit date references, conflicting temporal signals, or context.

Do not discard potentially outdated information.

Preserve it as evidence and flag its freshness.

---

### `unknown`

Use when a Brand Brain-relevant question cannot be answered from the supplied source.

Do not create an `unknown` item for every absent field. Return it only when absence itself is relevant to the extraction task.

---

## Hard Rules

1. Never fill missing information using industry knowledge or common sense.
2. Never silently transform a claim into a fact.
3. Never resolve contradictions between sources.
4. Never assume newer-looking information is automatically correct.
5. Never create target audiences, positioning, values, goals, tone, or business priorities unless supported by the source.
6. Never infer demographic attributes from services alone.
7. Never infer business strategy merely from business category.
8. Preserve meaningful ambiguity.
9. Prefer `unknown` or no extraction over unsupported completion.
10. Every extracted item must be traceable to evidence in the supplied source.

---

## Evidence Requirements

Each item should include the smallest useful piece of supporting source evidence.

Evidence should:

- preserve the original meaning;
- avoid unnecessarily long quotations;
- identify its location within the source where possible;
- retain the original language;
- never fabricate a quotation.

---

## Field Candidates

When relevant, map evidence to one or more candidate Brand Brain areas:

- `identity.name`
- `identity.description`
- `identity.location`
- `identity.languages`
- `services`
- `products`
- `audience`
- `positioning`
- `value_proposition`
- `proof_points`
- `pricing`
- `offers`
- `tone`
- `content_patterns`
- `visual_identity`
- `cta_patterns`
- `constraints`
- `other`

`field_candidate` is routing metadata only.

It does not mean the extracted value should become the final Brand Brain value.

---

## Evidence Strength

Assign one of:

- `strong`
- `medium`
- `weak`

Use `strong` when the source explicitly and unambiguously supports the extraction.

Use `medium` when interpretation is required but evidence is substantial.

Use `weak` for tentative inference or ambiguous evidence.

Do not output numeric confidence.

Numeric confidence is calculated by the application layer.

---

## Freshness

Return one of:

- `current`
- `potentially_outdated`
- `unknown`

Use `current` only when the supplied source contains a reliable temporal signal supporting current validity.

Do not assume that a currently accessible webpage necessarily contains current information.

---

## Output

Return structured JSON only.

Each evidence item should follow this conceptual structure:

```json
{
  "type": "fact | claim | observation | inference | outdated_candidate | unknown",
  "field_candidate": "services",
  "value": "Human-readable extracted value",
  "normalized_value": "Optional normalized representation",
  "evidence_strength": "strong | medium | weak",
  "freshness": "current | potentially_outdated | unknown",
  "evidence": {
    "text": "Exact supporting excerpt or compact evidence description",
    "source_location": "Page section, heading, post context, or equivalent"
  }
}
```

Multiple distinct facts or claims should normally be represented as separate evidence items.

Do not merge unrelated evidence into one item.

---

## Failure Behavior

If the supplied source contains no Brand Brain-relevant information, return an empty evidence array.

If source content is incomplete or malformed, extract only what can be supported.

If the source is ambiguous, preserve ambiguity rather than resolving it.

If a conclusion requires information unavailable in the source, do not produce that conclusion.