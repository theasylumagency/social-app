# Prompt Contract: `brand-brain-finalizer`

## Purpose

Apply founder answers and approved conflict resolutions to the current Brand Brain and produce the finalized operational Brand Brain state.

The finalizer is responsible for converting explicit founder decisions into protected canonical knowledge while preserving unresolved uncertainty.

It determines whether the Brand Brain is operationally ready for the Social Operator.

---

# 1. Input

The model receives:

- current canonical Brand Brain draft;
- founder questions that were asked;
- founder answers;
- mappings from each question to Brand Brain fields;
- unresolved conflicts;
- existing hypotheses;
- protected founder-confirmed values;
- MVB requirements;
- optional application-level validation results.

---

# 2. Core Responsibility

The finalizer must:

1. interpret each founder answer within the scope of the question asked;
2. update only the intended Brand Brain fields;
3. mark explicitly resolved values as `confirmed`;
4. close or update relevant conflicts;
5. preserve unrelated existing values;
6. preserve hypotheses that were not confirmed or disproved;
7. determine whether MVB requirements are satisfied;
8. return operational readiness status;
9. report any remaining blocking issues.

The finalizer must not reinterpret the entire Brand Brain from scratch.

---

# 3. Founder Answer Authority

A direct founder answer to a valid question normally creates:

```text
status = confirmed
```

for the specific decision covered by that answer.

Example:

Question:

> Which service should get the most attention over the next few weeks?

Answer:

> Implants.

Update:

```text
offer.priority_offers = implantology
status = confirmed
```

Do not infer that:

- implantology is the only primary service;
- implant patients are the only audience;
- the entire brand positioning should become implant-focused.

Confirmation scope must remain narrow.

---

# 4. Scope Protection

Every founder question must have an explicit field update scope.

The finalizer may update only:

- mapped fields;
- fields deterministically dependent on the selected answer;
- conflict records explicitly associated with the question.

Do not use one answer as permission to rewrite unrelated Brand Brain sections.

---

# 5. Answer Mapping

Where possible, answer interpretation should be deterministic.

Example:

```json
{
  "question_id": "fq_001",
  "selected_option": "calm_expert"
}
```

may map to:

```json
{
  "voice.primary_tone": ["calm", "expert"],
  "voice.energy": "restrained"
}
```

The mapping should preferably be supplied by application logic or question metadata.

The finalizer should not invent additional mappings unless explicitly allowed.

---

# 6. Free-Text Answers

When the founder provides free text:

1. preserve the original answer;
2. normalize it only enough to fit the canonical schema;
3. avoid adding meaning not present in the response;
4. return the interpreted canonical value;
5. flag ambiguity when interpretation is uncertain.

Example:

Founder answer:

> I don't want us to sound cheap or pushy.

Possible updates:

```text
positioning.avoid_positioning += cheap
voice.avoid_patterns += aggressive sales pressure
```

Do not convert this automatically into:

```text
positioning = premium
```

unless the founder explicitly said so.

---

# 7. Confirmation vs Preference

Not every founder interaction represents a permanent brand decision.

The finalizer must distinguish:

- enduring brand confirmation;
- current operational priority;
- temporary campaign preference;
- one-time instruction.

Example:

> Push whitening this month.

Should update:

```text
offer.priority_offers
content.priority_topics
```

with relevant temporal context.

It should not permanently redefine:

```text
offer.primary_services
```

---

# 8. Temporal Scope

When founder intent is time-bounded, preserve scope.

Conceptually:

```json
{
  "value": "teeth whitening",
  "status": "confirmed",
  "validity": {
    "type": "temporary",
    "until": null,
    "context": "current content cycle"
  }
}
```

Exact persistence may differ, but temporary priorities must not silently become permanent strategy.

---

# 9. Conflict Resolution

When a founder answer resolves a conflict:

- set the selected canonical value;
- mark it `confirmed`;
- close the related conflict;
- retain conflict history for auditability;
- preserve rejected candidate evidence.

Conceptually:

```json
{
  "conflict_id": "cf_004",
  "status": "resolved",
  "resolution": {
    "selected_value": "premium specialist positioning",
    "resolved_by": "founder",
    "resolved_at": "..."
  }
}
```

Do not delete conflicting source evidence.

---

# 10. Founder Chooses "Both"

If the founder explicitly confirms that apparently conflicting values are both valid, preserve both with context.

Example:

> Premium for implants, accessible/value-focused for hygiene.

This should not remain a generic unresolved conflict.

Instead create contextual canonical rules.

Possible representation:

```text
positioning.default = premium_specialist
positioning.contextual_variants.hygiene = accessible_value
```

Only do this when context is explicit.

---

# 11. Founder Chooses "Use Your Best Judgment"

When the founder delegates a decision:

- do not mark the selected model hypothesis as `confirmed`;
- retain status as `hypothesis` or `inferred`;
- record that operational use was authorized.

Conceptually:

```json
{
  "status": "hypothesis",
  "usage_permission": "founder_delegated"
}
```

This distinction is important.

The founder authorized the Operator to proceed.

The founder did not confirm that the hypothesis is objectively correct.

---

# 12. Skip Behavior

When the founder skips a non-blocking question:

- preserve existing Brand Brain state;
- retain any safe hypothesis;
- leave the unresolved field open where necessary;
- do not consume further interpretation.

Skip must never be treated as agreement.

---

# 13. Ambiguous Founder Answers

If a founder answer does not clearly resolve the intended field:

- do not force a canonical interpretation;
- retain the original answer;
- return an ambiguity flag.

Example:

Question:

> Which tone should guide the brand?

Answer:

> Something nice but not too much.

Do not convert this confidently into:

```text
professional, restrained, warm
```

unless mapping is reasonably clear.

The system may either:

- retain the previous safe hypothesis;
- or mark the field unresolved.

Do not automatically generate another founder question in this component.

---

# 14. Contradictory Founder Answers

If the founder gives a new answer that conflicts with a previously confirmed value:

the latest explicit answer may replace the older value **only when the new answer clearly addresses the same decision**.

Preserve history.

Example:

Earlier:

> Use a formal tone.

Later explicit answer:

> Actually, let's make it more conversational.

The canonical value may change.

Record:

```text
previous confirmation superseded
```

Do not silently erase the earlier decision.

---

# 15. Existing Founder-Confirmed Fields

Fields unrelated to the current answer must remain unchanged.

The finalizer must be conservative.

A finalization pass should normally produce a small, explainable diff rather than rewrite the entire Brand Brain.

---

# 16. Hypothesis Handling

After founder answers, each hypothesis may be:

- confirmed;
- rejected;
- retained;
- superseded;
- unresolved.

### Confirmed

Founder explicitly validates it.

```text
hypothesis → confirmed
```

### Rejected

Founder explicitly contradicts it.

Remove it from canonical use but retain its history.

### Retained

Founder skipped or delegated.

Keep:

```text
status = hypothesis
```

### Superseded

Founder provides a different canonical answer.

### Unresolved

Evidence remains insufficient and no usable founder answer exists.

---

# 17. Evidence Handling

Founder confirmation does not erase source provenance.

A confirmed value may still retain supporting evidence.

Conceptually:

```json
{
  "value": "calm and professional",
  "status": "confirmed",
  "sources": ["ev_012", "ev_045"],
  "confirmed_by": "founder"
}
```

This preserves explainability.

---

# 18. Confidence Interaction

The finalizer does not calculate numeric confidence.

It may emit state transitions that application logic later converts into confidence changes.

Example:

```text
hypothesis → confirmed
```

should normally cause the application layer to assign high authority.

---

# 19. MVB Evaluation

After applying founder answers, evaluate whether the Brand Brain contains:

1. at least one usable service or product;
2. at least one usable content language;
3. one usable tone definition.

Return:

```text
mvb_ready = true | false
```

---

# 20. Operational Readiness

Operational readiness is broader than completeness.

Suggested states:

- `ready`
- `ready_with_uncertainty`
- `blocked`

---

## `ready`

MVB exists and no unresolved high-risk issue prevents safe content generation.

---

## `ready_with_uncertainty`

MVB exists, but some non-blocking fields remain:

- unknown;
- inferred;
- hypothesis;
- deferred conflict.

This should be a normal successful onboarding outcome.

---

## `blocked`

The Operator cannot safely generate useful content because a required component is missing or critically conflicted.

Examples:

- no known service/product;
- no usable language;
- no safe tone;
- unresolved prohibition affecting ordinary content;
- factual conflict that makes intended content unsafe.

---

# 21. Completeness Is Not a Goal

Do not classify a Brand Brain as blocked simply because:

- positioning is incomplete;
- audience objections are unknown;
- proof is sparse;
- content pillars are provisional;
- some hypotheses remain.

The system should begin working as soon as it can do so safely and usefully.

---

# 22. Safe Operating Envelope

The finalizer may return a compact set of restrictions for downstream generation.

Example:

```json
{
  "safe_operating_envelope": {
    "avoid_fields": [
      "offer.pricing_context"
    ],
    "allowed_content_modes": [
      "educational",
      "service_explanation",
      "trust_building"
    ]
  }
}
```

Use only when unresolved issues materially constrain generation.

Do not create unnecessary restrictions.

---

# 23. Remaining Issues

Return only unresolved issues that matter operationally.

Conceptually:

```json
{
  "remaining_issues": [
    {
      "field": "positioning.core_position",
      "status": "hypothesis",
      "blocking": false
    }
  ]
}
```

Do not list every empty Brand Brain field.

---

# 24. Output Structure

Return structured JSON only.

Recommended conceptual structure:

```json
{
  "brand_brain": {},
  "applied_confirmations": [],
  "resolved_conflicts": [],
  "remaining_issues": [],
  "mvb": {
    "ready": true,
    "missing": []
  },
  "operational_status": "ready_with_uncertainty",
  "safe_operating_envelope": {}
}
```

---

# 25. Applied Confirmations

For auditability, return a compact change list.

Example:

```json
{
  "question_id": "fq_003",
  "fields_updated": [
    "voice.primary_tone",
    "voice.energy"
  ],
  "status": "confirmed"
}
```

Do not include unnecessary narrative.

---

# 26. Minimal Diff Principle

Finalization should modify only what founder input or valid resolution actually changes.

Do not regenerate fields that are already correct.

This reduces:

- accidental drift;
- unexplained changes;
- confirmation loss;
- model-induced inconsistency.

---

# 27. Idempotency

Applying the same founder answers to the same Brand Brain state should produce semantically equivalent output.

The finalizer should avoid creative reinterpretation.

This component should behave closer to a structured transformation engine than a creative model.

---

# 28. Failure Behavior

If founder answers are missing:

- return the Brand Brain unchanged;
- preserve pending questions;
- evaluate readiness from current state.

If one answer cannot be interpreted:

- apply all other valid answers;
- flag only the ambiguous item.

If application-provided mappings are invalid:

- do not guess destructive updates;
- return a mapping error for that item.

If no changes are necessary:

- return the current Brand Brain unchanged.

---

# 29. Non-Responsibilities

The finalizer must not:

- generate new hypotheses;
- generate new founder questions;
- crawl or inspect sources;
- independently resolve new conflicts;
- generate social content;
- calculate numeric confidence;
- change unrelated founder-confirmed fields;
- attempt to make the Brand Brain complete.