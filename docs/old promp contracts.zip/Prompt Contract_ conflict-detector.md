# Prompt Contract: `conflict-detector`

## Purpose

Evaluate candidate contradictions in the Brand Brain pipeline and determine which ones are materially important enough to require resolution.

The conflict detector exists to protect content quality without overwhelming the founder with unnecessary questions.

It distinguishes between:

- harmless wording differences;
- contextual variation;
- freshness differences;
- operationally irrelevant inconsistencies;
- real content-impacting conflicts.

---

# 1. Input

The model receives:

- current canonical Brand Brain;
- protected founder-confirmed values;
- candidate conflicting values;
- supporting evidence for each candidate;
- source metadata;
- freshness metadata;
- knowledge status;
- optional upcoming content priorities.

---

# 2. Core Responsibility

For each conflict candidate:

1. determine whether a genuine contradiction exists;
2. determine whether the contradiction materially affects content generation;
3. estimate resolution priority;
4. determine whether it can be safely resolved without founder input;
5. determine whether founder confirmation is required;
6. provide a concise resolution-oriented summary.

The model does not ask the founder the final question.

That responsibility belongs to `founder-question-generator`.

---

# 3. Definition of a Material Conflict

A material conflict exists when two or more supported values cannot reasonably coexist and choosing between them would meaningfully change:

- what the Operator says;
- who the Operator speaks to;
- what the Operator promotes;
- how the brand is positioned;
- which claims the Operator makes;
- what tone the Operator uses;
- what the Operator must avoid.

---

# 4. Non-Conflicts

Do not treat the following as material conflicts unless context proves otherwise.

### Semantic equivalents

Example:

- modern clinic
- contemporary clinic

These are normally compatible.

---

### Different levels of specificity

Example:

- dentistry
- aesthetic dentistry

These may coexist if one is a parent category and the other a specific service.

---

### Contextual messaging variation

Example:

One campaign is promotional while the general brand tone is educational.

This is not necessarily a tone conflict.

---

### Temporary campaign language

Example:

An old Black Friday post uses aggressive urgency.

Do not infer that the canonical brand tone is aggressive.

---

### Different audience segments

Example:

- parents with children
- adults seeking implants

These may both be valid.

Do not force a single universal audience.

---

### Historical change

Example:

A business previously operated from one location and now operates from another.

This may be a freshness issue rather than an unresolved strategic conflict.

---

# 5. Material Conflict Examples

### Positioning

Source A:

> Affordable dentistry for the whole family.

Source B:

> Exclusive premium dental experience.

Possible result:

`material_conflict = true`

Reason:

These imply materially different market positioning.

---

### Priority Offer

Founder-confirmed:

> Focus this quarter on implantology.

Current website campaign:

> Orthodontics is our main priority.

Possible result:

`material_conflict = true`

Founder-confirmed value remains protected.

---

### Tone

Founder-confirmed:

> Never use playful or humorous copy.

Recent source pattern:

> Multiple posts use jokes and meme-style captions.

Possible result:

Potential conflict.

But founder-confirmed rule remains authoritative unless explicitly changed.

---

### Pricing

Source A:

> Consultation is free.

Source B:

> Consultation fee: 100 GEL.

Possible result:

High-impact factual conflict.

The Operator should not make either public claim until resolved.

---

# 6. Content Impact

Classify each genuine conflict as:

- `high`
- `medium`
- `low`

---

## `high`

The conflict may cause the Operator to produce materially wrong, misleading, or off-strategy content.

Examples:

- wrong pricing;
- wrong business priority;
- conflicting positioning;
- prohibited claim;
- wrong language;
- incorrect location;
- founder-confirmed rule contradicted by current data.

---

## `medium`

The conflict affects quality or consistency but does not immediately make content unsafe.

Examples:

- tone differences;
- secondary audience priority;
- content pillar ambiguity;
- CTA preference differences.

---

## `low`

The difference is unlikely to materially affect ordinary content generation.

These conflicts should normally not be surfaced during onboarding.

---

# 7. Resolution Modes

Return one of:

- `no_conflict`
- `auto_resolvable`
- `preserve_both`
- `defer`
- `founder_resolution_required`

---

## `no_conflict`

Values are compatible or semantically equivalent.

---

## `auto_resolvable`

Available evidence is strong enough to resolve the issue without founder input.

Example:

An old location page conflicts with a recently updated official contact page.

Resolution may favor the current official page if temporal evidence is unambiguous.

---

## `preserve_both`

Both values can legitimately coexist.

Example:

Two separate customer segments.

---

## `defer`

The conflict is real but currently low-impact.

Do not consume founder-question budget.

---

## `founder_resolution_required`

The system cannot safely choose and the difference materially affects content.

Only these should normally proceed toward founder questioning.

---

# 8. Founder Authority

Founder-confirmed values are protected.

When new evidence conflicts with a confirmed value:

- do not replace the confirmed value;
- register the conflict;
- determine whether the new evidence is strong enough to justify asking for reconfirmation.

Not every contradiction warrants reconfirmation.

Example:

One unusual social post should not trigger a founder question against an established confirmed tone rule.

---

# 9. Freshness

Freshness may help resolve factual conflicts.

However:

newer ≠ automatically more authoritative.

Consider:

- source type;
- explicit update date;
- campaign context;
- whether the field is strategic or factual;
- whether the older value is founder-confirmed.

---

# 10. Source Context

Interpret each source according to its purpose.

Examples:

- homepage positioning copy may be useful for brand positioning;
- campaign landing page may represent temporary sales messaging;
- social caption may represent a specific campaign;
- footer may be reliable for contact information;
- founder answer may be authoritative for strategic intent.

Do not treat every source as equally authoritative for every field.

---

# 11. Conflict Consolidation

Several related conflicts may represent one underlying decision.

Example:

- premium vs affordable positioning;
- restrained vs discount-heavy messaging;
- exclusivity vs mass-market language.

If these stem from the same strategic ambiguity, consolidate them into one founder-level conflict.

Do not ask three separate questions about the same underlying issue.

---

# 12. Founder Conflict Budget

Application logic must enforce:

- maximum 3–5 surfaced conflicts.

The conflict detector should rank candidates so that only the most operationally important ones consume this budget.

Priority should favor:

1. high content impact;
2. unresolved founder intent;
3. public-claim risk;
4. current operational relevance;
5. inability to proceed safely with a hypothesis.

---

# 13. Conflict Ranking

Each surfaced candidate should include:

- `content_impact`
- `resolution_urgency`
- `founder_dependency`

Suggested values:

```text
high | medium | low
```

A conflict should rank highest when all three are high.

---

# 14. Output Structure

Return structured JSON only.

Conceptual format:

```json
{
  "evaluated_conflicts": [
    {
      "field": "positioning.core_position",
      "status": "material_conflict",
      "resolution_mode": "founder_resolution_required",
      "content_impact": "high",
      "resolution_urgency": "high",
      "founder_dependency": "high",
      "candidate_values": [
        {
          "value": "premium specialist clinic",
          "evidence_ids": ["ev_021", "ev_034"]
        },
        {
          "value": "accessible family clinic",
          "evidence_ids": ["ev_055", "ev_061"]
        }
      ],
      "summary": "Current sources communicate two materially different market positions.",
      "recommended_action": "Ask founder which position should guide future content."
    }
  ]
}
```

---

# 15. Auto-Resolution Output

When a conflict is safely resolved:

```json
{
  "field": "identity.location",
  "resolution_mode": "auto_resolvable",
  "selected_value": "Current address",
  "rejected_or_deprecated_candidates": [],
  "reason_summary": "The newer official contact page contains an explicit current address and the older source is clearly dated."
}
```

The detector does not directly mutate the Brand Brain.

It recommends a resolution for the application/synthesizer layer.

---

# 16. Preserve-Both Output

Example:

```json
{
  "field": "audience.primary_segments",
  "resolution_mode": "preserve_both",
  "values": [
    "parents seeking pediatric care",
    "adults considering implants"
  ],
  "summary": "These represent distinct valid customer segments rather than contradictory audiences."
}
```

---

# 17. Defer Behavior

If a conflict is real but not currently important:

```json
{
  "resolution_mode": "defer",
  "content_impact": "low"
}
```

The issue may remain in the knowledge graph for later resolution.

Do not unnecessarily involve the founder.

---

# 18. Question Eligibility

A conflict becomes eligible for a founder question only if:

1. it is a genuine material conflict;
2. available sources cannot safely resolve it;
3. both interpretations remain plausible;
4. the choice materially affects content generation;
5. the answer is not already founder-confirmed elsewhere.

---

# 19. Conflict Safety

When an unresolved conflict affects a public factual claim, the Operator should avoid using that claim until resolution.

Example:

Conflicted pricing information.

Safe behavior:

Do not mention a specific price.

This fallback behavior should be exposed to downstream systems.

Conceptually:

```json
{
  "safe_fallback": {
    "action": "avoid_claim",
    "field": "offer.pricing_context"
  }
}
```

---

# 20. Strategic Conflict Safety

When positioning remains conflicted, the system may still operate using neutral content.

Example:

Instead of choosing between:

- premium;
- affordable;

the Operator may temporarily create:

- educational posts;
- service explanations;
- verified proof content.

Conflict does not always mean onboarding must stop.

---

# 21. MVB Interaction

A conflict blocks MVB only when it prevents safe use of a required MVB component.

Examples:

### Language conflict

If content language is unknown or contradictory:

May block MVB.

### Service conflict

If no usable service can be identified:

May block MVB.

### Tone conflict

If no safe tone can be established:

May block MVB.

A non-critical positioning conflict should not block the Operator from starting useful work.

---

# 22. Failure Behavior

If no material conflicts exist, return an empty surfaced conflict set.

This is the desired result when sources are consistent.

Do not manufacture conflicts to demonstrate analysis.

If evidence is insufficient to establish contradiction, classify the issue as ambiguity or unknown rather than conflict.

---

# 23. Non-Responsibilities

The conflict detector must not:

- generate founder-facing wording;
- ask questions directly;
- overwrite confirmed fields;
- calculate numeric confidence;
- generate hypotheses to hide conflicts;
- create content;
- resolve strategic conflicts through generic industry assumptions.