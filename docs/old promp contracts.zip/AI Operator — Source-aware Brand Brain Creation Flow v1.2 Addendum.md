# AI Operator — Source-aware Brand Brain Creation Flow v1.2 Addendum

## 1. Question Budget

Brand Brain onboarding-ს უნდა ჰქონდეს მკაფიო კითხვების ლიმიტი.

Founder-only questions:

- maximum 5–7 questions;
- ideally 3–5 questions for high-confidence brands;
- questions must be prioritized by impact on content generation.

Conflict questions:

- maximum 3–5 conflicts shown during onboarding;
- only conflicts that affect content generation, publishing, trust, contact info, offers, location, tone, or legal/sensitive claims should be shown immediately;
- low-impact conflicts can be stored in Brand Brain diagnostics and shown later in Brand Brain Settings.

Rule:

**If a question does not materially improve the first Weekly Cycle, it should not be asked during onboarding.**

---

## 2. Minimum Viable Brand Brain

Operator can be activated only if Minimum Viable Brand Brain is complete.

Minimum required fields:

```ts
type MinimumViableBrandBrain = {
  brandName: string;
  industry: string;
  location: string;
  primaryLanguage: string;
  confirmedOfferings: BrandOffering[]; // at least 1
  selectedTone: string[]; // at least 1
  boundaries: BrandBoundaryRules;
};
```

Activation requirements:

- at least 1 confirmed service/product/category;
- primary language selected;
- tone selected or accepted from recommendation;
- location provided at least city level;
- default boundary rules active;
- no unresolved critical conflict.

Critical conflicts include:

- unclear business identity;
- conflicting location/contact information;
- conflicting active offer;
- regulated/sensitive claim uncertainty;
- no confirmed offering.

If Minimum Viable Brand Brain is incomplete, user can choose:

- finish now;
- save draft;
- add missing info later.

But Operator cannot generate/publish a weekly cycle until the minimum is complete.

---

## 3. Default Boundary Rules

Boundaries must not depend only on founder input.

Most users will skip or under-answer the question:

> What should AI never say?

Therefore, system-level default rules are always active.

Universal default boundaries:

- do not invent prices;
- do not invent discounts;
- do not invent guarantees;
- do not invent deadlines;
- do not invent availability;
- do not invent product/service details;
- do not claim results unless provided by source or founder;
- do not attack competitors;
- do not make political, religious, discriminatory, or sensitive claims unless explicitly part of the brand and safe;
- do not use aggressive fake urgency;
- do not publish unsupported facts.

Industry-specific examples:

Healthcare / dental / wellness:

- do not promise medical results;
- do not imply guaranteed treatment outcome;
- do not use fear-based medical messaging;
- do not replace doctor consultation with post advice.

Finance / legal / insurance:

- do not give legal or financial guarantees;
- do not imply approval, payout, or result unless explicitly confirmed;
- do not present general information as professional advice.

Beauty / aesthetics:

- do not promise exact physical results;
- do not overuse insecurity-based messaging;
- do not imply that appearance determines personal worth.

Food / restaurant:

- do not invent ingredients, allergens, prices, or availability;
- do not claim “fresh today” unless confirmed.

Education / children:

- do not promise guaranteed outcomes;
- do not use manipulative parent guilt messaging.

Founder input can add rules, but cannot remove universal safety boundaries.

---

## 4. Social Ingest Preconditions

Website analysis can happen without account connection if the website is public.

Facebook Page and Instagram analysis require social connection through the relevant platform flow.

Onboarding should therefore request social connect early:

- Facebook Page connect;
- Instagram professional account connect;
- LinkedIn page connect, if supported.

Purpose of early connect:

- analyze previous posts;
- detect tone and CTA patterns;
- detect active or outdated offers;
- prepare publishing permissions;
- reduce manual onboarding questions.

If user does not connect social accounts:

- system can still use public website;
- system can use manual examples;
- system can create industry-based hypotheses;
- publishing remains unavailable until a supported publishing channel is connected.

Personal Facebook profile content is not treated as official connected business source.

---

## 5. Internal Brand Brain Metadata

Brand Brain JSON must include versioning, timestamps, and provenance.

```ts
type BrandBrain = {
  id: string;
  brandId: string;
  schemaVersion: string;
  createdAt: string;
  updatedAt: string;

  identity: BrandIdentity;
  languages: BrandLanguages;
  offerings: BrandOffering[];
  audience: BrandAudience;
  voice: BrandVoice;
  visualIdentity: VisualIdentity;
  boundaries: BrandBoundaryRules;
  sourceConfidence: SourceConfidence;
  conflicts: SourceConflict[];
  learnedPreferences: LearnedPreferences;

  provenance: BrandBrainProvenance;
};
```

Field provenance:

```ts
type FieldProvenance = {
  valuePath: BrandBrainPath;
  source:
    | "website"
    | "facebook_page"
    | "instagram_professional"
    | "manual_example"
    | "founder_input"
    | "industry_inference"
    | "system_default"
    | "operator_learning";
  sourceRef?: string;
  confidence: "low" | "medium" | "high";
  extractedAt: string;
  confirmedAt?: string;
  confirmedBy?: "founder" | "system";
};
```

Purpose:

- easier debugging;
- safer prompt construction;
- future schema migrations;
- clear explanation of why Operator writes in a certain way;
- better post-onboarding editing.

---

## 6. Language Model Update

Languages should not be hardcoded in the data model.

Use ISO-style string codes internally.

```ts
type BrandLanguages = {
  primaryLanguage: string; // e.g. "ka", "en", "ru"
  secondaryLanguages?: string[];
};
```

UI can still limit visible options in MVP:

- Georgian;
- English;
- Russian.

But the schema should remain open for future languages.

---

## 7. Typed SmartQuestion Affects

SmartQuestion.affects should not be a loose string array.

It should point to typed Brand Brain paths.

```ts
type BrandBrainPath =
  | "identity.name"
  | "identity.location"
  | "offerings"
  | "audience.primarySegments"
  | "audience.desiredCustomers"
  | "audience.lessDesiredCustomers"
  | "voice.selectedTone"
  | "voice.emojiPolicy"
  | "voice.salesIntensity"
  | "visualIdentity.colors"
  | "visualIdentity.visualStyle"
  | "boundaries"
  | "conflicts"
  | "learnedPreferences.notes";
```

Updated SmartQuestion:

```ts
type SmartQuestion = {
  id: string;
  reason: string;
  priority: "low" | "medium" | "high" | "critical";
  sourceGap:
    | "website_missing"
    | "social_unclear"
    | "conflicting_sources"
    | "founder_only"
    | "risk_boundary"
    | "blank_brand_hypothesis"
    | "manual_examples_needed"
    | "visual_identity_missing";
  question: string;
  answerType:
    | "single_choice"
    | "multi_choice"
    | "short_text"
    | "priority_ranking"
    | "confirm_or_edit";
  affects: BrandBrainPath[];
};
```

This allows answers to update the correct Brand Brain fields automatically.

---

## 8. Later Completion

If the user clicks “მოგვიანებით დასრულება,” the system saves Brand Brain as draft.

Draft states:

```ts
type BrandBrainStatus =
  | "draft_incomplete"
  | "minimum_ready"
  | "active"
  | "needs_review";
```

Rules:

- draft_incomplete: cannot generate weekly cycle;
- minimum_ready: can generate draft posts, but cannot autopublish until publishing channel is connected;
- active: full Operator workflow available;
- needs_review: source conflict, expired offer, or major edit requires confirmation.

---

## 9. Success Metric

The primary quality metric for Brand Brain onboarding:

**First-week post approval rate without manual editing.**

Target:

- MVP baseline: measure only;
- v1 goal: improve approval rate over time by using corrections as learned preferences.

Supporting metrics:

- number of edits per generated post;
- number of rejected posts;
- number of “regenerate” actions;
- number of tone corrections;
- number of factual corrections;
- time from Add Brand to Operator activation.

This metric keeps onboarding focused on the right goal:

**not collecting more information, but producing posts the user can approve quickly.**