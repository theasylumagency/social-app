# Prompt Contract: `founder-question-generator`

## Purpose

Convert a small set of high-value unresolved Brand Brain gaps and material conflicts into concise, founder-facing questions.

The founder-question generator exists to obtain information that cannot be safely inferred or resolved from available sources.

Its goal is **not** to complete the Brand Brain.

Its goal is to ask the minimum number of questions required to materially improve the Operator's ability to create useful content.

---

# 1. Input

The model receives:

- current Brand Brain draft;
- unresolved high-value fields;
- material conflicts eligible for founder resolution;
- approved hypotheses;
- protected founder-confirmed values;
- MVB status;
- existing evidence summaries;
- previously asked founder questions;
- previously received founder answers;
- remaining question budget.

---

# 2. Core Responsibility

For each eligible unresolved issue:

1. determine whether a founder question is truly necessary;
2. consolidate related issues into one question where possible;
3. phrase the question in simple business language;
4. provide useful answer options when appropriate;
5. make it easy to skip or defer non-blocking questions;
6. encode which Brand Brain fields the answer is intended to update.

The model should optimize for information value per question.

---

# 3. Founder-Only Principle

Ask only questions whose answers depend materially on founder or authorized business intent.

Good founder-only questions include:

- what should we promote most right now?
- who matters most as an audience?
- how should the brand sound?
- what should the Operator never say?
- which of two conflicting positioning directions is correct?

Do not ask questions that can reasonably be answered from sources.

Bad examples:

- What is your website?
- What services do you offer?
- What city are you located in?
- What languages appear on your website?

If these can be extracted reliably, do not ask the founder.

---

# 4. Hard Question Budget

Application logic must enforce:

- maximum **5–7 founder-only questions total** during initial Brand Brain onboarding;
- maximum **3–5 surfaced conflicts**.

The prompt must respect the supplied remaining budget.

If 2 question slots remain, return no more than 2 questions.

Never exceed the application-provided budget.

---

# 5. Question Priority

Questions should be ranked by expected impact on actual content generation.

Default priority order:

1. MVB-blocking unknowns;
2. strategic conflicts with high content impact;
3. current business priority;
4. audience direction;
5. tone/voice;
6. prohibited messaging or sensitive constraints;
7. medium-value refinement.

Do not ask low-value questions merely because budget remains.

Returning fewer questions is valid.

---

# 6. MVB Questions

If a required MVB component is missing, prioritize it.

MVB requires:

1. at least one usable service or product;
2. at least one usable content language;
3. a usable tone definition.

Only ask about these if they genuinely cannot be established from sources.

Example:

> Which language should we primarily create posts in?

may be required.

But if all connected channels clearly and consistently use Georgian, the system should usually infer/observe this rather than ask.

---

# 7. Prefer Questions About Decisions, Not Descriptions

Whenever possible, ask the founder to make a useful decision rather than describe the business from scratch.

Bad:

> Tell us about your target audience.

Better:

> Which customers do you most want the Operator to focus on right now?

Bad:

> Describe your brand tone.

Better:

> Which feels closer to how you want the brand to sound: calm and expert, warm and conversational, or more energetic and promotional?

This reduces cognitive load and produces more operational answers.

---

# 8. Source-Aware Questioning

Questions should demonstrate that the system already did the work.

If evidence exists, reference it concisely.

Example:

> Your site emphasizes implants, orthodontics and aesthetic dentistry. Which of these should get the most attention in the next few weeks?

Better than:

> What services should we promote?

For conflicts:

> Your website sounds premium, while recent Facebook posts lean heavily on discounts. Which direction should guide future content?

This builds trust by showing that the Operator analyzed existing material.

---

# 9. Do Not Expose Internal Taxonomy

Founder-facing questions should not use internal terms such as:

- hypothesis;
- inference;
- evidence candidate;
- confidence score;
- canonical field;
- source precedence;
- conflict object.

Use plain business language.

---

# 10. Question Types

Use one of:

- `single_select`
- `multi_select`
- `short_text`
- `confirm`
- `rank`

---

## `single_select`

Use when one clear strategic choice is needed.

Example:

> What should the brand feel closest to?

Options:

- premium and restrained;
- warm and accessible;
- expert and clinical.

---

## `multi_select`

Use when several valid answers may coexist.

Example:

> Which customer groups matter most right now?

Allow up to a reasonable number of selections.

---

## `short_text`

Use only when predefined options would distort the answer.

Examples:

- “What should the Operator never say or promise?”
- “Is there one business priority we have missed?”

Do not default to open-ended text.

---

## `confirm`

Use when the system has a strong candidate and only needs validation.

Example:

> From your current content, we read the tone as calm and professional. Should we use that as the default?

Options:

- Yes
- Adjust it

Confirmation questions are preferable to asking founders to define something already strongly supported.

---

## `rank`

Use sparingly when relative priority is what matters.

Example:

> Rank these by what you want to promote most this month.

Do not use ranking when one simple selection is enough.

---

# 11. Options Should Be Evidence-Informed

When generating answer options:

- derive them from existing evidence where possible;
- include genuinely distinct choices;
- avoid meaningless adjective variations;
- include `other` only when useful;
- avoid overwhelming users with long lists.

Recommended default:

- 2–4 options.

Bad:

- professional
- very professional
- expert
- highly expert
- sophisticated

Good:

- calm and expert
- warm and conversational
- energetic and promotional

---

# 12. Avoid Leading Questions

Do not manipulate the founder toward the model's preferred interpretation.

Bad:

> Your premium positioning seems clearly stronger. Should we continue with that?

Better:

> Your website communicates a premium feel, while recent social posts are more price-led. Which direction should future content follow?

The system may have a recommendation internally, but the question must preserve genuine choice.

---

# 13. Conflict Questions

A conflict question should:

1. summarize the contradiction simply;
2. explain why it matters only when helpful;
3. ask for one decision;
4. map the answer back to the relevant field.

Example:

> Your website presents the brand as premium and specialist-led, while recent campaigns focus on affordability and discounts. Which should be the default positioning for regular content?

Options:

- premium / specialist
- accessible / value-focused
- use both depending on service
- neither — I'll specify

---

# 14. Consolidate Related Conflicts

Do not ask multiple questions that represent one underlying strategic choice.

Example conflicts:

- premium vs affordable;
- restrained vs discount-heavy;
- exclusive vs broad-access messaging.

These may become one question:

> Should the brand generally feel premium and selective, accessible and value-focused, or intentionally balance both?

One founder answer may resolve several Brand Brain fields.

---

# 15. Priority Questions

A high-value onboarding question often concerns current priority.

Example:

> What should the Operator help the business achieve first?

Possible options:

- generate inquiries or bookings;
- promote a specific service/product;
- build awareness and trust;
- educate the audience;
- reactivate existing customers.

However, only ask this if goals cannot be established sufficiently from current context.

---

# 16. Time-Bounded Intent

Strategic business priorities may be temporary.

Questions should distinguish:

- enduring brand decisions;
- current campaign priorities.

Example:

> Which service should get the most attention over the next few weeks?

should update:

`offer.priority_offers`

not permanently redefine:

`offer.primary_services`.

---

# 17. Skip and Defer Behavior

Non-blocking questions should allow the user to defer.

Conceptually:

```text
Skip for now
```

or:

```text
Use your best judgment
```

when a safe hypothesis exists.

Do not offer “use your best judgment” for high-risk factual or strategic conflicts that require explicit confirmation.

---

# 18. "Use Your Best Judgment"

This option is useful when:

- the system has a defensible hypothesis;
- operational risk is low;
- founder input would improve quality but is not essential.

If selected, retain the relevant field as:

```text
status = hypothesis
```

Do not upgrade it to `confirmed`.

---

# 19. Founder Answer Authority

A direct founder answer should normally produce:

```text
status = confirmed
```

for the specific decision answered.

However, do not overextend the scope of confirmation.

Example:

Founder selects:

> Promote implants first.

This confirms:

`offer.priority_offers = implantology`

It does not mean:

- implantology is the only service;
- implant patients are the sole audience;
- the entire brand positioning is implant-focused.

---

# 20. Answer Scope

Every question should declare which fields it can update.

Conceptually:

```json
{
  "question_id": "fq_003",
  "updates": [
    "offer.priority_offers",
    "content.priority_topics"
  ]
}
```

This allows deterministic application logic after the founder answers.

---

# 21. Multi-Field Questions

One answer may legitimately update multiple related fields.

Example:

Question:

> Which direction should the brand sound closest to?

Answer:

> Calm and expert.

May update:

- `voice.primary_tone`
- `voice.energy`
- potentially `voice.formality`

But only where mapping is explicitly defined.

Do not use vague answers to rewrite unrelated Brand Brain sections.

---

# 22. Question Wording

Questions should be:

- short;
- specific;
- conversational;
- non-technical;
- answerable without preparation.

Prefer one sentence.

Use a second sentence only when source context materially helps.

Avoid:

- marketing jargon;
- strategy workshop language;
- compound questions;
- abstract brand theory.

---

# 23. One Decision Per Question

Avoid:

> Who is your audience, what do they care about, and what should we promote to them?

Split only when each decision is important enough to justify a question slot.

Otherwise choose the highest-value decision.

---

# 24. User Effort

Minimize typing.

Default preference:

1. `confirm`
2. `single_select`
3. `multi_select`
4. `rank`
5. `short_text`

Open-ended founder questionnaires should be the exception.

---

# 25. Existing Founder Answers

Never ask the same question again if an existing confirmed answer already resolves it.

If new evidence materially challenges an old confirmed answer, only ask again if the conflict detector explicitly marks reconfirmation as warranted.

---

# 26. Reconfirmation

When reconfirming, acknowledge the previous decision.

Example:

> Earlier you chose a calm, professional tone. Recent content has become much more playful. Should we keep the original tone as the default?

Do not pretend the system forgot the earlier answer.

---

# 27. Question Output Structure

Return structured JSON only.

Conceptual format:

```json
{
  "questions": [
    {
      "question_id": "fq_001",
      "priority": "high",
      "type": "single_select",
      "question": "Which service should get the most attention over the next few weeks?",
      "context": "Your current channels emphasize implants, orthodontics and aesthetic dentistry.",
      "options": [
        {
          "id": "implants",
          "label": "Implants"
        },
        {
          "id": "orthodontics",
          "label": "Orthodontics"
        },
        {
          "id": "aesthetic",
          "label": "Aesthetic dentistry"
        },
        {
          "id": "balanced",
          "label": "Keep them balanced"
        }
      ],
      "allow_skip": true,
      "allow_best_judgment": true,
      "updates": [
        "offer.priority_offers",
        "content.priority_topics"
      ],
      "source_issue_ids": [
        "gap_004"
      ]
    }
  ]
}
```

---

# 28. Context Field

`context` is optional.

Use it only when it improves trust or explains the choice.

Good:

> Your website emphasizes three service categories equally.

Unnecessary:

> We need this answer to improve our Brand Brain model.

Do not expose implementation details.

---

# 29. Question Priority

Use:

- `high`
- `medium`
- `low`

Only high and selected medium-priority questions should normally appear in onboarding.

Low-priority questions should generally be deferred to progressive Brand Brain refinement.

---

# 30. Ordering

Order questions so onboarding feels natural.

Recommended sequence:

1. blocking practical decisions;
2. current business priority;
3. audience;
4. tone;
5. constraints;
6. conflicts/refinements.

However, conflict urgency may override this order.

---

# 31. Progressive Disclosure

Do not show all questions merely because they exist internally.

Questions may be shown:

- one at a time;
- in a short review sequence;
- grouped only when tightly related.

The prompt determines question content, not final interface presentation.

---

# 32. Failure Behavior

Return an empty question array when:

- the Brand Brain is already sufficiently actionable;
- unresolved issues are low-value;
- available sources can answer remaining gaps;
- safe hypotheses can cover uncertainty;
- question budget is exhausted.

An empty question array is a successful result.

---

# 33. Non-Responsibilities

The founder-question generator must not:

- invent new conflicts;
- calculate numeric confidence;
- modify the Brand Brain directly;
- decide canonical values before an answer is received;
- ask factual questions that sources can resolve;
- perform source extraction;
- generate content;
- expose internal model reasoning;
- attempt to complete every empty Brand Brain field.