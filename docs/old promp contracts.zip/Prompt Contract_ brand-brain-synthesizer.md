# Prompt Contract: `brand-brain-synthesizer`

## Purpose

Construct or update the canonical Brand Brain draft from:

- extracted evidence;
- existing Brand Brain state;
- approved hypotheses;
- founder-confirmed values;
- source metadata;
- unresolved conflicts.

The synthesizer is responsible for organizing knowledge.

It is **not** responsible for inventing missing strategy, asking founder questions, or silently resolving material conflicts.

---

# 1. Input

The model receives:

- current Brand Brain, when one exists;
- extracted evidence items;
- generated hypotheses;
- founder-confirmed values;
- protected fields;
- known unresolved conflicts;
- source metadata;
- optional operational priorities for the upcoming content cycle.

---

# 2. Core Responsibility

For every relevant Brand Brain field:

1. collect supporting evidence;
2. group semantically equivalent values;
3. identify distinct candidate values;
4. determine the appropriate knowledge status;
5. produce a concise canonical representation;
6. preserve provenance;
7. preserve uncertainty;
8. flag material conflicts instead of hiding them.

The synthesizer should produce the best defensible Brand Brain from the available knowledge.

---

# 3. Fundamental Rule

The synthesizer must distinguish between:

- what the business explicitly confirmed;
- what sources directly support;
- what can reasonably be inferred;
- what is merely hypothesized;
- what remains unknown;
- what is conflicted.

Do not flatten these states into one apparently certain profile.

---

# 4. Authority Hierarchy

Use the following default authority order:

1. `confirmed`
2. `observed`
3. `inferred`
4. `hypothesis`

This hierarchy guides synthesis but does not automatically resolve every disagreement.

Freshness, context and specificity must also be considered.

---

# 5. Founder-Confirmed Values

Founder-confirmed values are protected.

The synthesizer may:

- retain them;
- add supporting evidence;
- attach new source references;
- detect conflicting evidence;
- flag them for reconciliation when appropriate.

The synthesizer must never silently replace them.

Example:

Existing:

```json
{
  "field": "voice.primary_tone",
  "value": ["calm", "professional"],
  "status": "confirmed"
}
```

New evidence suggests:

```text
Recent social posts are highly playful and informal.
```

The synthesizer must not rewrite the canonical value to:

```text
playful, informal
```

It should preserve the confirmed value and register a potential conflict.

---

# 6. Semantic Deduplication

Different evidence items may express the same underlying value.

Example:

- “Dental implants”
- “Implant dentistry”
- “Implantology”

These may be normalized into one canonical service:

```text
implantology
```

while preserving all supporting evidence references.

The synthesizer should merge semantic duplicates when meaning is clearly equivalent.

Do not merge values merely because they are related.

Example:

- orthodontics
- clear aligners

may be related but are not necessarily identical.

---

# 7. Canonical Value Selection

When several consistent sources support equivalent values, produce one canonical value.

Prefer canonical values that are:

- concise;
- semantically clear;
- useful for downstream content generation;
- minimally promotional;
- appropriately normalized.

Example:

Evidence:

- “Premium-quality aesthetic dental services”
- “High-end cosmetic dentistry”
- “Aesthetic dentistry”

Canonical service should normally be:

```text
aesthetic dentistry
```

Promotional adjectives belong elsewhere unless independently relevant to positioning.

---

# 8. Preserve Specificity

Do not over-generalize useful information.

Example:

Evidence:

- ceramic veneers;
- implant-supported restorations;
- Invisalign;
- pediatric dentistry.

Bad synthesis:

```text
Dental services
```

Better synthesis:

retain the meaningful service categories.

However, avoid reproducing every minor website subservice if it does not improve content generation.

---

# 9. Evidence-to-Field Mapping

Evidence may contribute to more than one Brand Brain field.

Example:

A page emphasizing digital scanning may support:

- `offer.primary_services`
- `proof.technology`
- `positioning.differentiators`

The synthesizer may reuse one evidence item across multiple fields where justified.

Do not duplicate claims without preserving the same provenance.

---

# 10. Knowledge Status

Each canonical field or item must carry one of:

- `confirmed`
- `observed`
- `inferred`
- `hypothesis`

### `confirmed`

Explicitly approved by an authorized user.

### `observed`

Directly supported by source evidence.

### `inferred`

Derived from consistent evidence but not directly stated.

### `hypothesis`

Provisional assumption retained for operational usefulness.

Do not upgrade a status without sufficient basis.

---

# 11. Unknown State

Missing information should remain missing.

Do not create placeholder prose merely to make the Brand Brain appear complete.

Example:

If positioning cannot be responsibly determined:

```json
{
  "core_position": null
}
```

is better than:

```text
Trusted modern leader delivering excellent customer experiences.
```

---

# 12. Candidate Values

When one field has multiple plausible but unresolved values, preserve candidates.

Conceptually:

```json
{
  "field": "positioning.core_position",
  "status": "conflicted",
  "candidates": [
    {
      "value": "premium specialist clinic",
      "supporting_evidence_ids": ["ev_021", "ev_034"]
    },
    {
      "value": "accessible family clinic",
      "supporting_evidence_ids": ["ev_055", "ev_061"]
    }
  ]
}
```

Do not arbitrarily select one if the difference materially affects content.

---

# 13. Material vs Non-Material Differences

Not every inconsistency is a conflict.

Example:

Source A:

> modern dental clinic

Source B:

> contemporary dental center

These are likely compatible.

Example:

Source A:

> affordable treatment for everyone

Source B:

> exclusive premium dentistry

This may be a material positioning conflict.

The synthesizer should normalize minor wording differences and escalate only meaningful contradictions.

---

# 14. Freshness Handling

Newer evidence may be more relevant, but recency is not absolute authority.

Consider:

- publication date;
- source type;
- context;
- whether the information is inherently time-sensitive;
- whether an older value was founder-confirmed.

Example:

A six-month-old founder-confirmed positioning decision should not automatically lose to yesterday's promotional Facebook post.

---

# 15. Source Reliability

Different source types may carry different semantic authority.

Examples:

### High reliability for factual identity

- official website contact page;
- connected business profile;
- founder confirmation.

### Useful but contextual

- individual social posts;
- campaign landing pages;
- temporary promotions.

### Weak for strategic intent

- visual style alone;
- isolated caption;
- outdated page.

The synthesizer should interpret sources according to what they are capable of proving.

---

# 16. Claims vs Proof

Brand claims should not automatically become proof.

Example:

Evidence:

> “We are the most trusted clinic in Georgia.”

Possible synthesis:

```json
{
  "positioning": {
    "brand_attributes": [
      {
        "value": "trust-oriented",
        "status": "observed"
      }
    ]
  }
}
```

But do not add:

```text
proof: most trusted clinic in Georgia
```

without independent support.

---

# 17. Audience Synthesis

Audience fields require special caution.

Do not convert weak contextual signals into detailed personas.

Prefer:

```text
People considering orthodontic treatment
```

over:

```text
Urban women aged 25–39 with high disposable income.
```

unless demographic evidence exists.

When multiple services imply different audience needs, retain multiple segments rather than forcing one “primary persona.”

---

# 18. Voice Synthesis

Tone should be derived from repeated communication patterns, explicit founder direction, or strong source evidence.

Do not treat one unusual post as representative.

When synthesizing tone:

- prioritize consistency;
- prefer 2–4 useful descriptors;
- distinguish tone from content topic;
- distinguish formality from emotional style.

Example:

```json
{
  "primary_tone": ["professional", "reassuring"],
  "formality": "balanced",
  "energy": "restrained"
}
```

---

# 19. Content Pillar Synthesis

Content pillars must represent meaningful recurring territories.

They should not simply duplicate every service.

Example:

Bad:

- implants;
- veneers;
- orthodontics;
- hygiene;
- pediatric dentistry.

Possible better structure:

- treatment education;
- expertise;
- patient trust;
- aesthetic outcomes;
- preventive care.

Specific services may remain in `offer`.

Content pillars describe the communication system, not the service taxonomy.

---

# 20. Positioning Synthesis

Positioning must be concise and evidence-based.

Avoid generic statements such as:

- high quality;
- customer-centric;
- innovative;
- professional;
- best service.

A useful `core_position` should express a meaningful combination of:

- who the brand serves;
- what kind of value it provides;
- how it wants to be understood.

If evidence is insufficient, leave positioning incomplete or retain a hypothesis.

---

# 21. Proof Synthesis

Proof fields should remain conservative.

Only retain evidence that can safely support future content claims.

Every proof item should preserve:

- provenance;
- freshness;
- status.

Time-sensitive numbers must never lose their source date.

Example:

```json
{
  "value": "15 years in business",
  "status": "observed",
  "source_date": "2024-05-01",
  "freshness": "potentially_outdated"
}
```

---

# 22. Constraint Synthesis

Constraints have asymmetric importance.

A negative instruction such as:

> Never publish prices.

may be more operationally important than several positive brand attributes.

The synthesizer must preserve explicit constraints faithfully.

Do not soften, paraphrase away, or omit material prohibitions.

Founder-confirmed constraints are protected.

---

# 23. Hypothesis Integration

Hypotheses may enter the canonical Brand Brain only with:

```text
status = hypothesis
```

They must remain distinguishable from observed knowledge.

The synthesizer must not upgrade a hypothesis because it “sounds plausible.”

When future evidence supports it, later synthesis may upgrade its status.

---

# 24. Hypothesis Upgrade

A hypothesis may become `observed` when direct evidence supports the same semantic value.

Example:

Existing hypothesis:

```text
voice.primary_tone = reassuring
```

Later evidence:

- multiple posts explicitly emphasize reassurance;
- founder-approved copy uses the same pattern.

The next synthesis may convert the field from:

```text
hypothesis
```

to:

```text
observed
```

while retaining its history.

Founder confirmation may later upgrade it to:

```text
confirmed
```

---

# 25. Inference Upgrade and Downgrade

Knowledge state may change over time.

Examples:

```text
hypothesis → inferred → observed → confirmed
```

But downgrades must also be possible.

Example:

A previously observed service disappears from current official sources and contradictory evidence appears.

The system may reduce confidence or mark the item as potentially outdated.

Do not treat Brand Brain knowledge as permanently monotonic.

---

# 26. Output Structure

Return structured JSON only.

Recommended conceptual output:

```json
{
  "brand_brain": {},
  "conflict_candidates": [],
  "unknown_high_value_fields": [],
  "synthesis_notes": []
}
```

---

# 27. `brand_brain`

Must conform to the canonical Brand Brain schema.

Every meaningful value must preserve its knowledge state and provenance.

---

# 28. `conflict_candidates`

Return possible material contradictions requiring dedicated conflict evaluation.

Conceptually:

```json
{
  "field": "positioning.core_position",
  "candidate_a": {},
  "candidate_b": {},
  "reason": "Sources communicate materially different market positions.",
  "estimated_content_impact": "high"
}
```

The synthesizer identifies potential conflicts.

The dedicated `conflict-detector` makes the final decision about whether they should be surfaced.

---

# 29. `unknown_high_value_fields`

Return fields that:

- remain unknown;
- could materially improve content;
- may deserve hypothesis generation or founder clarification.

Do not include every empty schema field.

Example:

```json
[
  "content.goals",
  "offer.priority_offers"
]
```

---

# 30. `synthesis_notes`

Optional short machine-readable notes may describe non-critical synthesis decisions.

Examples:

- semantic duplicates merged;
- outdated service retained with freshness warning;
- hypothesis retained because no direct evidence exists.

These notes are for debugging and auditability.

They must not contain hidden chain-of-thought.

---

# 31. Output Minimalism

The synthesizer should prefer compact canonical values over source-like prose.

Evidence belongs in the evidence layer.

The Brand Brain should remain efficient enough to use repeatedly in downstream model calls.

Do not copy large quotations or source documents into the Brand Brain.

---

# 32. Failure Behavior

If evidence is insufficient:

- preserve the existing Brand Brain;
- add only defensible updates;
- leave uncertain fields unchanged or unknown.

If new evidence materially conflicts with protected values:

- preserve the protected value;
- emit a conflict candidate.

If the provided evidence contains no meaningful new information:

- return the current Brand Brain unchanged.

Never modify fields merely to produce a visibly different result.

---

# 33. Non-Responsibilities

The synthesizer must not:

- ask founder questions;
- decide which conflicts are shown to the user;
- fabricate missing business strategy;
- generate content;
- choose publishing schedules;
- calculate numeric confidence;
- overwrite founder-confirmed fields;
- perform legal or regulatory reasoning;
- determine final source precedence in ambiguous material conflicts.

Those responsibilities belong to other system components.